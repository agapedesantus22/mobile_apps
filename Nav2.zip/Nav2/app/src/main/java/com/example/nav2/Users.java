package com.example.nav2;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Users extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.users);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }
}
