package com.example.app3;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Users2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.users2);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }
}
