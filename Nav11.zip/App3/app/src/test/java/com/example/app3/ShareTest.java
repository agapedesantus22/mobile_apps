package com.example.app3;

import static org.junit.jupiter.api.Assertions.*;

class ShareTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }
}